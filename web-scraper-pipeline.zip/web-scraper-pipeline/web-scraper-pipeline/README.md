# Web Scraper & Data Pipeline API Service

## Overview

**Web Scraper & Data Pipeline API Service** is a production‑ready microservice designed to ingest data from arbitrary web pages, normalise it, store it in a relational database, and expose the data via an API and a dashboard.  
This service is ideal for startups that need to automate the collection of public information for analytics, monitoring, or internal tooling.

The project leverages **FastAPI** for the backend API, **Playwright** and **BeautifulSoup** for HTML/JavaScript scraping, **SQLAlchemy** with **PostgreSQL** for persistence, and **Streamlit** for a lightweight dashboard.  
A simple scheduler is included to demonstrate how recurring scraping tasks might be implemented. The entire stack is containerised with **Docker** and orchestrated using **docker‑compose**.

## Features

- **/scrape Endpoint**: Accepts a URL, intelligently chooses between Playwright (for dynamic pages) and BeautifulSoup (for static pages), extracts structured data (title, meta description, H1 tags, internal links, table data, raw HTML), normalises it, stores it in PostgreSQL, and returns a summary response.
- **/records Endpoint**: Retrieves the most recent scraped records from the database, with optional filtering by source URL and adjustable limit.
- **Scheduling Service**: A simple async scheduler that allows recurring scraping tasks to be registered in code. Includes a placeholder `schedule_daily_scrape(url)` for demonstration.
- **Streamlit Dashboard**: Provides a visual overview of the data pipeline, including total record counts, records grouped by source, the latest scraped entries, search and filter functionality, and an optional word‑frequency chart.
- **Test Suite**: Basic pytest tests covering HTML parsing, data normalisation, and a mocked database insert flow.
- **Dockerised**: Both the API and dashboard run in separate containers with a shared PostgreSQL instance for persistence. Playwright dependencies are installed automatically.

## Architecture

The system follows a clean separation of concerns:

```
┌─────────────────────────────────────────────────────────────────────┐
│                             API (FastAPI)                         │
│                                                                  │
│ ┌──────────────┐      ┌─────────────────┐      ┌───────────────┐ │
│ │ /scrape      │────▶│ Scraper Service │────▶│ Normalisation │ │
│ │ endpoint     │     │ (Playwright/BS)  │     │ Service        │ │
│ └──────────────┘      └─────────────────┘      └───────────────┘ │
│     │                                          │                │
│     ▼                                          ▼                │
│ Database (SQLAlchemy/PostgreSQL) ◀──────────────                │
│                                                                  │
│ ┌──────────────┐                                             │
│ │ /records     │──▶ Returns stored records                   │
│ │ endpoint     │                                             │
│ └──────────────┘                                             │
└─────────────────────────────────────────────────────────────────────┘
                               ▲
                               │
                               ▼
                   Streamlit Dashboard (analytics)
```

*(Diagram generated with ASCII; for a graphic version, see the placeholder image below.)*

![Architecture Diagram](https://via.placeholder.com/800x400.png?text=Architecture+Diagram)

## Folder Structure

```
web-scraper-pipeline/
├─ app/
│  ├─ main.py                     # FastAPI application and setup
│  ├─ api/
│  │  ├─ scrape.py                # /scrape endpoint definition
│  │  └─ records.py               # /records endpoint definition
│  ├─ services/
│  │  ├─ scraper_service.py       # Core scraping logic (Playwright/BeautifulSoup)
│  │  ├─ normalization_service.py # Cleans and normalises scraped data
│  │  └─ scheduler_service.py     # Simple asyncio scheduler for recurring tasks
│  ├─ models/
│  │  └─ record_model.py          # SQLAlchemy model for scraped records
│  ├─ config.py                   # Pydantic settings for environment variables
│
├─ dashboard/
│  └─ dashboard.py                # Streamlit dashboard application
│
├─ tests/
│  └─ test_scraper.py             # Pytest suite for scraper and normaliser
│
├─ requirements.txt               # Python dependencies
├─ Dockerfile                     # Production build for API and dashboard
├─ docker-compose.yml             # Orchestrates API, DB, and dashboard containers
├─ README.md                      # Project documentation (this file)
├─ .env.example                   # Sample environment variables
```

## Getting Started

### Prerequisites

Ensure you have the following installed:

- **Python 3.11** or newer
- **Docker** and **Docker Compose** (for containerised deployment)
- Node.js is **not** required; Playwright is installed via Python.

### Local Development

1. **Clone the repository:**

   ```bash
   git clone <repo-url>
   cd web-scraper-pipeline
   ```

2. **Create a virtual environment and install dependencies:**

   ```bash
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   # Install Playwright browsers (only once)
   python -m playwright install
   ```

3. **Set up environment variables:**

   Copy `.env.example` to `.env` and fill in your configuration:

   ```bash
   cp .env.example .env
   nano .env  # Edit values as needed
   ```

4. **Start PostgreSQL:**  
   Create a local PostgreSQL database and update `DATABASE_URL` in your `.env` file accordingly.  
   You can use Docker or a local installation.

5. **Run database migrations:**  
   The application will automatically create the necessary tables on first run.  
   For production usage, consider using a migration tool such as Alembic.

6. **Run the FastAPI server:**

   ```bash
   uvicorn app.main:app --reload --port 8000
   ```

7. **Run the Streamlit dashboard:**

   ```bash
   streamlit run dashboard/dashboard.py --server.port 8501
   ```

8. **Access the API and dashboard:**

   - API documentation: [http://localhost:8000/docs](http://localhost:8000/docs)
   - Dashboard: [http://localhost:8501](http://localhost:8501)

### Running with Docker

The project provides a full Docker setup to orchestrate the API, the database, and the dashboard.

1. **Prepare environment variables:**  
   Create a `.env` file at the project root by copying `.env.example` and adjusting values as needed.

2. **Build and start the stack:**

   ```bash
   docker-compose up --build
   ```

   This command builds the application image (installing dependencies and Playwright) and starts three containers:

   - **api**: FastAPI application accessible at `http://localhost:8000`
   - **db**: PostgreSQL database on port `5432`
   - **dashboard**: Streamlit dashboard on `http://localhost:8501`

3. **Stop and clean up:**

   ```bash
   docker-compose down
   ```

### Environment Variables

All sensitive or environment‑specific settings are loaded via environment variables. Use `.env.example` as a template.

| Variable             | Description                                                                      | Example                                                         |
|---------------------|----------------------------------------------------------------------------------|-----------------------------------------------------------------|
| `DATABASE_URL`      | SQLAlchemy connection string for PostgreSQL                                      | `postgresql+psycopg2://user:pass@db:5432/dbname`                |
| `PLAYWRIGHT_HEADLESS` | Whether Playwright runs in headless mode (`true` or `false`)                     | `true`                                                          |
| `LOG_LEVEL`         | Logging level for the application (`DEBUG`, `INFO`, `WARNING`, `ERROR`)          | `INFO`                                                          |
| `SCRAPER_TIMEOUT`   | Timeout (in seconds) for scraping operations                                      | `30`                                                            |

## API Usage

### Health Check

```
GET /health
Response: {"status":"ok"}
```

### Scrape a URL

```
POST /scrape
Content-Type: application/json
{
  "url": "https://example.com"
}

Response:
{
  "status": "success",
  "records_saved": 1,
  "source": "https://example.com"
}
```

This endpoint crawls the provided URL, extracts structured information, normalises it, and stores it in the database. If the page relies heavily on JavaScript, Playwright will be used; otherwise, BeautifulSoup is employed for speed.

### Retrieve Records

```
GET /records?limit=50&source=example.com

Response:
[
  {
    "id": "...uuid...",
    "source_url": "https://example.com",
    "scraped_at": "2025-11-18T10:15:30.123Z",
    "title": "Example Title",
    "description": "Meta description...",
    "h1_tags": ["Heading 1", "Another H1"],
    "links": ["/page1", "/page2"],
    "table_data": [{"Column A": "Value"}, ...],
    "raw_html": "<html>...</html>"
  },
  ...
]
```

This endpoint returns the latest scraped records. The `limit` query parameter controls how many results are returned (default 50), and the optional `source` parameter filters records to a specific domain.

## Dashboard

The Streamlit dashboard offers a friendly interface for exploring scraped data:

- **Total Records**: Displays the total number of entries in the database.
- **Records by Source**: A bar chart grouping the number of records per source URL.
- **Latest Scraped Items**: Shows the most recent records with key fields visible.
- **Search/Filter**: Filter records by URL or search terms.
- **Word Frequency Chart (optional)**: Visualises the most common words across scraped titles and descriptions.

You can access the dashboard at [http://localhost:8501](http://localhost:8501) when running via Docker or from your local machine.

![Dashboard Screenshot](https://via.placeholder.com/800x400.png?text=Dashboard+Screenshot)

## Running Playwright

Playwright is used under the hood to render pages that rely on JavaScript. The project automatically installs Playwright and its dependencies during the Docker build. For local development, run:

```bash
python -m playwright install
```

By default, Playwright runs in headless mode as controlled by `PLAYWRIGHT_HEADLESS`. Set it to `false` in your `.env` to debug scraping visually.

## Testing

The project uses **pytest** for unit testing. Tests reside in the `tests/` directory and cover:

- Correct extraction and parsing of HTML elements.
- Normalisation logic to ensure consistent output.
- Database insertion flow with mocks.

Run the tests with:

```bash
pytest -q
```

## Deployment

The service is designed to be deployed on any platform supporting Docker. Below are high‑level steps for three popular platforms. In all cases, configure the environment variables via the platform’s settings and never commit secrets to source control.

### Render

1. Push the repository to GitHub.  
2. Create a **Web Service** for the API on Render; set the start command to `uvicorn app.main:app --host 0.0.0.0 --port 8000`.  
3. Add a **Background Worker** or separate service if you wish to run the scheduler independently.  
4. Add a **PostgreSQL** database through Render’s add‑ons and update `DATABASE_URL`.  
5. Create another Web Service for the dashboard with start command `streamlit run dashboard/dashboard.py --server.port 8501 --server.address 0.0.0.0`.  
6. Ensure both services use the same database and environment variables.

### Railway

1. Import the repository into Railway.  
2. Add a PostgreSQL plugin and copy the connection string into `DATABASE_URL`.  
3. Configure an **Environment** for the API and another for the dashboard, each with their own start commands.  
4. Deploy.

### AWS (ECS/Fargate)

1. Build Docker images using the provided `Dockerfile` and push them to **Amazon ECR**.  
2. Create an **ECS Task Definition** with two containers (API and dashboard) connected to the same RDS PostgreSQL instance.  
3. Use **Fargate** to run the task in a service and configure an **Application Load Balancer** to route traffic to the appropriate ports.  
4. Set environment variables in the ECS task definition.  
5. Optionally schedule tasks via **CloudWatch Events** or **ECS Scheduled Tasks** for recurring scraping.

## Example Test Payloads

### Sample HTML for Testing

To manually test the scraper without external dependencies, you can create a simple HTML file such as `tests/static/example.html` with the following content:

```html
<!DOCTYPE html>
<html>
<head>
  <title>Test Page</title>
  <meta name="description" content="This is a test page for scraping.">
</head>
<body>
  <h1>Main Heading</h1>
  <h1>Second Heading</h1>
  <p>Some content here.</p>
  <table>
    <thead><tr><th>Name</th><th>Age</th></tr></thead>
    <tbody><tr><td>Alice</td><td>30</td></tr><tr><td>Bob</td><td>25</td></tr></tbody>
  </table>
  <a href="/internal/link">Internal Link</a>
</body>
</html>
```

Send this HTML through the scraper’s normalisation functions in the tests to validate behaviour.

---

This completes the overview and usage instructions for the **Web Scraper & Data Pipeline API Service**. For additional questions or contributions, please open an issue or submit a pull request.