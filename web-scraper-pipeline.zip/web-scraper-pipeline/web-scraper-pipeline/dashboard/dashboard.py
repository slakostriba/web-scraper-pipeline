"""Streamlit dashboard for exploring scraped records.

This dashboard connects to the PostgreSQL database used by the API
service and provides summary metrics and interactive views of the
scraped data. Use this dashboard to monitor scraping activity,
inspect recent records, and analyse word frequencies.
"""

from __future__ import annotations

import os
from collections import Counter
from typing import List, Optional

import pandas as pd
import streamlit as st
from sqlalchemy import create_engine, text
from dotenv import load_dotenv


# Load environment variables from .env if present
load_dotenv()
DATABASE_URL = os.getenv("DATABASE_URL")
if not DATABASE_URL:
    st.error("DATABASE_URL environment variable is not set.")
    st.stop()

# Create SQLAlchemy engine
engine = create_engine(DATABASE_URL, pool_pre_ping=True)


@st.cache_data(show_spinner=False)
def get_total_records() -> int:
    """Return the total number of records in the database."""
    with engine.connect() as conn:
        result = conn.execute(text("SELECT COUNT(*) FROM records"))
        count = result.scalar()
    return count or 0


@st.cache_data(show_spinner=False)
def get_records_by_source() -> pd.DataFrame:
    """Return a dataframe grouping records by their source URL."""
    with engine.connect() as conn:
        df = pd.read_sql(
            "SELECT source_url, COUNT(*) as count FROM records GROUP BY source_url ORDER BY count DESC",
            conn,
        )
    return df


@st.cache_data(show_spinner=False)
def get_recent_records(limit: int = 20) -> pd.DataFrame:
    """Return the most recent scraped records up to the specified limit."""
    query = f"SELECT * FROM records ORDER BY scraped_at DESC LIMIT {limit}"
    with engine.connect() as conn:
        df = pd.read_sql(query, conn, parse_dates=["scraped_at"])
    return df


def filter_records(df: pd.DataFrame, search_term: Optional[str]) -> pd.DataFrame:
    """Filter records dataframe by a search term present in title or description."""
    if search_term:
        mask = (
            df["title"].astype(str).str.contains(search_term, case=False, na=False)
            | df["description"].astype(str).str.contains(search_term, case=False, na=False)
        )
        return df[mask]
    return df


def compute_word_frequency(texts: List[str], stopwords: Optional[set[str]] = None, top_n: int = 10) -> pd.DataFrame:
    """Compute word frequency from a list of texts and return as a dataframe."""
    stopwords = stopwords or set()
    words: List[str] = []
    for text in texts:
        for word in str(text).split():
            clean = word.strip().lower()
            if clean and clean not in stopwords:
                words.append(clean)
    counts = Counter(words)
    most_common = counts.most_common(top_n)
    return pd.DataFrame(most_common, columns=["word", "count"])


def main() -> None:
    """Run the Streamlit dashboard."""
    st.set_page_config(page_title="Web Scraper Dashboard", layout="wide")
    st.title("Web Scraper & Data Pipeline Dashboard")

    # Display summary metrics
    col1, col2 = st.columns(2)
    with col1:
        total = get_total_records()
        st.metric("Total Records", total)
    with col2:
        df_sources = get_records_by_source()
        st.bar_chart(df_sources.set_index("source_url"), use_container_width=True)
        st.caption("Records by Source URL")

    # Search/filter bar
    search = st.text_input("Search titles/descriptions", "")

    # Latest records
    df_recent = get_recent_records(limit=50)
    df_filtered = filter_records(df_recent, search)
    st.subheader("Latest Scraped Items")
    if df_filtered.empty:
        st.info("No records found.")
    else:
        display_cols = ["scraped_at", "source_url", "title", "description"]
        st.dataframe(df_filtered[display_cols], use_container_width=True)

    # Optional word frequency chart
    st.subheader("Word Frequency (Top 10)")
    words_df = compute_word_frequency(
        texts=list(df_recent["title"].dropna()) + list(df_recent["description"].dropna()),
        stopwords={"the", "and", "to", "of", "a", "in", "for", "on", "with"},
    )
    st.bar_chart(words_df.set_index("word"), use_container_width=True)


if __name__ == "__main__":
    main()