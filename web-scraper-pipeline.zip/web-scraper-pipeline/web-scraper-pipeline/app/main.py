"""Application entrypoint for the Web Scraper & Data Pipeline API Service.

This module configures the FastAPI app, sets up the database
connections, initialises the scheduler service, and includes API
routers. It exposes a simple health check endpoint and ensures that
any scheduled tasks are gracefully shut down on application exit.
"""

from __future__ import annotations

import logging

from fastapi import FastAPI
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from .config import settings
from .models.record_model import Base
from .api.scrape import router as scrape_router
from .api.records import router as records_router
from .services.scheduler_service import SchedulerService


def configure_logging() -> None:
    """Configure root logging based on the configured log level."""
    level = getattr(logging, settings.log_level.upper(), logging.INFO)
    logging.basicConfig(level=level, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")


def init_db(app: FastAPI) -> None:
    """Initialise the database engine and session factory.

    Creates a SQLAlchemy engine and binds it to a sessionmaker, then
    attaches the session factory to the application state. This
    function also creates database tables on startup. In a production
    environment, proper migration tooling (Alembic) should be used
    instead.
    """
    engine = create_engine(settings.database_url, pool_pre_ping=True)
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    Base.metadata.create_all(bind=engine)
    app.state.SessionLocal = SessionLocal  # type: ignore[assignment]


def create_application() -> FastAPI:
    """Factory to create the FastAPI application."""
    configure_logging()
    app = FastAPI(title="Web Scraper & Data Pipeline API Service")
    init_db(app)

    # Initialise scheduler with session factory; tasks can be scheduled in startup
    scheduler = SchedulerService(session_factory=lambda: app.state.SessionLocal())
    app.state.scheduler = scheduler  # type: ignore[assignment]

    @app.on_event("startup")
    async def startup_event() -> None:
        """Hook executed on server startup.

        Use this to schedule recurring scraping tasks. For example:

        ``scheduler.schedule_daily_scrape('https://example.com')``
        """
        # Example: schedule a daily scrape for an example site. Comment
        # out or modify as needed.
        # scheduler.schedule_daily_scrape("https://example.com")
        pass

    @app.on_event("shutdown")
    async def shutdown_event() -> None:
        """Hook executed on server shutdown to cancel scheduler tasks."""
        await scheduler.shutdown()

    @app.get("/health")
    def health_check() -> dict[str, str]:
        """Simple health check endpoint."""
        return {"status": "ok"}

    # Include API routers
    app.include_router(scrape_router)
    app.include_router(records_router)

    return app


app = create_application()