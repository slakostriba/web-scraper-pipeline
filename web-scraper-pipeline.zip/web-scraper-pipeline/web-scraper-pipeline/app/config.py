"""Configuration module using Pydantic settings.

This module defines a ``Settings`` class that encapsulates all
environment‑dependent configuration for the application. The settings
are loaded from environment variables, optionally from a ``.env`` file
if present. Use ``settings`` throughout the application to access
configuration values.
"""

from functools import lru_cache
from typing import Optional

from pydantic import BaseSettings, Field


class Settings(BaseSettings):
    """Application configuration loaded from environment variables."""

    database_url: str = Field(..., env="DATABASE_URL")
    playwright_headless: bool = Field(True, env="PLAYWRIGHT_HEADLESS")
    log_level: str = Field("INFO", env="LOG_LEVEL")
    scraper_timeout: int = Field(30, env="SCRAPER_TIMEOUT")

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


@lru_cache()
def get_settings() -> Settings:
    """Return a cached settings instance.

    This helper allows other modules to import ``settings`` without
    repeatedly parsing environment variables. Use ``get_settings()`` if
    you need a fresh copy (rare).
    """
    return Settings()


settings: Settings = get_settings()