"""API router for initiating web scraping tasks.

Defines the ``/scrape`` endpoint which accepts a URL, scrapes and
normalises its content, stores the result in the database, and
returns a summary of the operation.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, HTTPException, Request, status
from pydantic import BaseModel, Field, HttpUrl

from ..models.record_model import Record
from ..services.scraper_service import scraper_service
from ..services.normalization_service import normalization_service


router = APIRouter()
logger = logging.getLogger(__name__)


class ScrapeRequest(BaseModel):
    """Request payload for the /scrape endpoint."""

    url: HttpUrl = Field(..., description="The absolute URL of the page to scrape.")


class ScrapeResponse(BaseModel):
    """Response payload for the /scrape endpoint."""

    status: str = Field(..., description="Indicates success or failure of the operation.")
    records_saved: int = Field(..., description="Number of records persisted to the database.")
    source: str = Field(..., description="The source URL that was scraped.")


@router.post("/scrape", response_model=ScrapeResponse, status_code=status.HTTP_201_CREATED)
async def scrape_endpoint(payload: ScrapeRequest, request: Request) -> ScrapeResponse:
    """Scrape a URL, normalise the data, store it, and return a summary.

    Parameters
    ----------
    payload: ScrapeRequest
        JSON body containing the URL to scrape.
    request: Request
        FastAPI request object, used to access application state for DB sessions.

    Returns
    -------
    ScrapeResponse
        Summary of the scraping operation.
    """
    url = str(payload.url)
    try:
        raw_data = await scraper_service.scrape(url)
    except Exception as exc:
        logger.exception("Scraping failed: %s", exc)
        raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=f"Failed to scrape {url}: {exc}") from exc

    normalized_data = normalization_service.normalize(raw_data)

    # Persist to database
    SessionLocal = request.app.state.SessionLocal  # type: ignore[attr-defined]
    db = SessionLocal()
    records_saved = 0
    try:
        record = Record(
            source_url=url,
            title=normalized_data.get("title"),
            description=normalized_data.get("description"),
            h1_tags=normalized_data.get("h1_tags"),
            links=normalized_data.get("links"),
            table_data=normalized_data.get("table_data"),
            raw_html=normalized_data.get("raw_html"),
        )
        db.add(record)
        db.commit()
        records_saved = 1
    except Exception as exc:
        db.rollback()
        logger.exception("Database insertion failed: %s", exc)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to save scraped data to database") from exc
    finally:
        db.close()

    return ScrapeResponse(status="success", records_saved=records_saved, source=url)