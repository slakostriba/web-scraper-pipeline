"""API router for retrieving stored scraping records."""

from __future__ import annotations

from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from ..models.record_model import Record


router = APIRouter()


class RecordResponse(BaseModel):
    """Schema representing a scraped record."""

    id: str = Field(...)
    source_url: str = Field(...)
    scraped_at: str = Field(...)
    title: Optional[str] = None
    description: Optional[str] = None
    h1_tags: Optional[List[str]] = None
    links: Optional[List[str]] = None
    table_data: Optional[List[dict]] = None
    raw_html: Optional[str] = None

    class Config:
        orm_mode = True


def get_db(request: Request) -> Session:
    """Dependency for retrieving a database session from the app state."""
    SessionLocal = request.app.state.SessionLocal  # type: ignore[attr-defined]
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.get("/records", response_model=List[RecordResponse])
def list_records(
    limit: int = Query(50, gt=0, le=200, description="Number of records to return (1-200)."),
    source: Optional[str] = Query(None, description="Filter records by source URL domain."),
    db: Session = Depends(get_db),
) -> List[RecordResponse]:
    """Retrieve the most recent scraped records.

    Parameters
    ----------
    limit: int
        Maximum number of records to return (default 50, capped at 200).
    source: str | None
        Optional domain filter. Records are matched if their source URL
        contains this value.
    db: Session
        SQLAlchemy session provided by dependency injection.

    Returns
    -------
    list of RecordResponse
        A list of serialised record objects.
    """
    query = db.query(Record)
    if source:
        # Perform a simple LIKE filter on the source_url column
        query = query.filter(Record.source_url.ilike(f"%{source}%"))
    records = (
        query.order_by(Record.scraped_at.desc()).limit(limit).all()
    )
    return records