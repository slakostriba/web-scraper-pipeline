"""Service for normalising scraped web data.

Normalisation ensures that data extracted from diverse web pages
conforms to a consistent structure and format before persisting it to
the database. This module performs whitespace trimming, deduplication,
and lower‑casing where appropriate, and sanitises table data.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional


logger = logging.getLogger(__name__)


class NormalizationService:
    """Normalise scraped data dictionaries."""

    def normalize(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Return a new dictionary with normalised values.

        Parameters
        ----------
        data: dict
            Raw scraped data with possible irregular spacing, casing, and
            duplicate entries.

        Returns
        -------
        dict
            A copy of ``data`` with normalised fields. Lists are
            deduplicated and trimmed, strings are stripped of leading
            and trailing whitespace, and table data cell values are
            stripped.
        """
        normalized: Dict[str, Any] = data.copy()

        # Normalise title and description
        for key in ("title", "description"):
            value = normalized.get(key)
            if isinstance(value, str):
                normalized[key] = value.strip()

        # Normalise lists of strings (h1_tags and links)
        for key in ("h1_tags", "links"):
            items = normalized.get(key)
            if items:
                # Remove duplicates while preserving order
                seen: set[str] = set()
                cleaned: List[str] = []
                for item in items:
                    if isinstance(item, str):
                        stripped = item.strip()
                        if stripped not in seen:
                            seen.add(stripped)
                            cleaned.append(stripped)
                normalized[key] = cleaned or None

        # Normalise table data: strip whitespace in cell values
        table_data = normalized.get("table_data")
        if table_data:
            cleaned_tables: List[dict[str, Any]] = []
            for row in table_data:
                if isinstance(row, dict):
                    cleaned_row = {k: (v.strip() if isinstance(v, str) else v) for k, v in row.items()}
                    cleaned_tables.append(cleaned_row)
            normalized["table_data"] = cleaned_tables or None

        return normalized


# Singleton instance
normalization_service = NormalizationService()