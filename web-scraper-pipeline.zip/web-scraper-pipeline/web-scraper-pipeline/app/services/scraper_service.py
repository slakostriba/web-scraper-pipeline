"""Service responsible for scraping and extracting data from web pages.

This module encapsulates all logic for fetching a web page, deciding
whether JavaScript rendering is required, parsing HTML with
BeautifulSoup, and extracting structured information. When JavaScript
rendering is needed, Playwright is used to obtain the fully rendered
HTML.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, List, Optional
from urllib.parse import urljoin, urlparse

import pandas as pd
from bs4 import BeautifulSoup
import httpx
from playwright.async_api import async_playwright

from ..config import settings


logger = logging.getLogger(__name__)


class ScraperService:
    """A service that scrapes web pages and extracts structured data."""

    def __init__(self, timeout: int | None = None) -> None:
        self.timeout = timeout or settings.scraper_timeout

    async def scrape(self, url: str) -> Dict[str, Any]:
        """Scrape the given URL and return extracted data.

        The method first attempts to fetch the page via HTTP and parse it
        with BeautifulSoup. If the page appears to rely on JavaScript or
        if parsing yields no meaningful content, Playwright is used to
        render the page fully. Extracted fields include the page title,
        meta description, H1 tags, internal links, table data, and raw
        HTML.

        Parameters
        ----------
        url: str
            The absolute URL to scrape.

        Returns
        -------
        dict
            A dictionary containing extracted fields. Missing values are
            represented by ``None``.
        """
        logger.info("Scraping URL: %s", url)
        html = await self._fetch_html(url)
        soup = BeautifulSoup(html, "html.parser")

        # Determine whether the page likely needs JS rendering
        if self._needs_js_rendering(soup):
            logger.debug("Falling back to Playwright for JS rendering")
            html = await self._fetch_with_playwright(url)
            soup = BeautifulSoup(html, "html.parser")

        data = {
            "title": self._extract_title(soup),
            "description": self._extract_description(soup),
            "h1_tags": self._extract_h1_tags(soup),
            "links": self._extract_internal_links(soup, base_url=url),
            "table_data": self._extract_table_data(html),
            "raw_html": html,
        }

        return data

    async def _fetch_html(self, url: str) -> str:
        """Fetch raw HTML using an HTTP client.

        Parameters
        ----------
        url: str
            The URL to fetch.

        Returns
        -------
        str
            The HTML content of the page.

        Raises
        ------
        httpx.HTTPError
            If the HTTP request fails.
        """
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(url)
                response.raise_for_status()
                return response.text
        except Exception as exc:
            logger.exception("HTTP fetch failed: %s", exc)
            raise

    def _needs_js_rendering(self, soup: BeautifulSoup) -> bool:
        """Determine if the page likely requires JS rendering.

        Heuristics used:
        - Presence of multiple <script> tags with a "src" attribute
        - Lack of an <h1> tag or title in the first fetch
        - Presence of known SPA frameworks in script tags

        Parameters
        ----------
        soup: BeautifulSoup
            Parsed HTML of the page.

        Returns
        -------
        bool
            True if the page should be rendered with JavaScript.
        """
        scripts = soup.find_all("script", src=True)
        if len(scripts) > 3:
            return True
        if not soup.title or not soup.find("h1"):
            return True
        for script in soup.find_all("script"):
            content = (script.get("src") or "") + (script.string or "")
            lowered = content.lower()
            if any(framework in lowered for framework in ("react", "vue", "angular", "svelte", "next.js")):
                return True
        return False

    async def _fetch_with_playwright(self, url: str) -> str:
        """Render the page using Playwright and return the HTML.

        Parameters
        ----------
        url: str
            The URL to fetch with Playwright.

        Returns
        -------
        str
            The fully rendered HTML of the page.

        Raises
        ------
        Exception
            Propagates any Playwright exceptions encountered.
        """
        timeout_ms = self.timeout * 1000
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=settings.playwright_headless)
            try:
                page = await browser.new_page()
                await page.goto(url, timeout=timeout_ms, wait_until="domcontentloaded")
                # wait for network idle to ensure dynamic content is loaded
                try:
                    await page.wait_for_load_state("networkidle", timeout=timeout_ms)
                except Exception:
                    pass
                content = await page.content()
            finally:
                await browser.close()
        return content

    def _extract_title(self, soup: BeautifulSoup) -> Optional[str]:
        title_tag = soup.find("title")
        if title_tag and title_tag.string:
            return title_tag.string.strip()
        return None

    def _extract_description(self, soup: BeautifulSoup) -> Optional[str]:
        meta_desc = soup.find("meta", attrs={"name": "description"})
        if meta_desc and meta_desc.get("content"):
            return meta_desc["content"].strip()
        return None

    def _extract_h1_tags(self, soup: BeautifulSoup) -> List[str] | None:
        tags = [h.get_text(strip=True) for h in soup.find_all("h1")]
        return tags if tags else None

    def _extract_internal_links(self, soup: BeautifulSoup, base_url: str) -> List[str] | None:
        links: List[str] = []
        parsed_base = urlparse(base_url)
        base_domain = parsed_base.netloc
        for a in soup.find_all("a", href=True):
            href = a["href"]
            parsed_href = urlparse(href)
            if not parsed_href.netloc or parsed_href.netloc == base_domain:
                full_url = urljoin(base_url, href)
                links.append(full_url)
        return links if links else None

    def _extract_table_data(self, html: str) -> List[dict[str, Any]] | None:
        """Extract table data using pandas to simplify parsing.

        Parameters
        ----------
        html: str
            Raw HTML content.

        Returns
        -------
        list of dict or None
            A flattened list of dictionaries representing table rows. Each
            dictionary maps column names to cell values. Returns ``None`` if
            no tables are present.
        """
        try:
            tables = pd.read_html(html)
        except ValueError:
            return None
        result: List[dict[str, Any]] = []
        for table in tables:
            # Convert each DataFrame to list of dicts
            result.extend(table.to_dict(orient="records"))
        return result if result else None


# Singleton instance of the scraper service
scraper_service = ScraperService()