"""Simple scheduling service for recurring scraping tasks.

This module implements a lightweight scheduler using Python's asyncio.
It demonstrates how recurring tasks (e.g., daily scrapes) might be
registered and executed without relying on external job queues like
Celery or Cron. The scheduler runs within the same event loop as
FastAPI, so tasks should be non‑blocking and carefully manage their
execution time.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Callable, Optional

from sqlalchemy.orm import Session

from ..models.record_model import Record
from ..services.scraper_service import scraper_service
from ..services.normalization_service import normalization_service


logger = logging.getLogger(__name__)


class SchedulerService:
    """Schedule and manage recurring scraping tasks."""

    def __init__(self, session_factory: Callable[[], Session], interval_seconds: int = 24 * 60 * 60) -> None:
        """Initialise the scheduler.

        Parameters
        ----------
        session_factory: callable
            A factory that returns a new SQLAlchemy ``Session`` when called.
        interval_seconds: int, optional
            Default interval for recurring tasks, in seconds (defaults to 24 hours).
        """
        self.session_factory = session_factory
        self.interval_seconds = interval_seconds
        self._tasks: list[asyncio.Task] = []

    def schedule_daily_scrape(self, url: str) -> None:
        """Schedule a daily scraping job for the specified URL.

        The job will run immediately and then repeat every ``interval_seconds``
        seconds. If an exception occurs during scraping, it is logged and
        the job continues on the next interval.

        Parameters
        ----------
        url: str
            The URL to scrape daily.
        """

        async def job() -> None:
            while True:
                try:
                    await self._scrape_and_store(url)
                except Exception as exc:
                    logger.exception("Scheduled scrape failed for %s: %s", url, exc)
                await asyncio.sleep(self.interval_seconds)

        task = asyncio.create_task(job())
        self._tasks.append(task)
        logger.info("Scheduled daily scrape for %s", url)

    async def _scrape_and_store(self, url: str) -> None:
        """Scrape a URL and store the result in the database."""
        data = await scraper_service.scrape(url)
        normalized = normalization_service.normalize(data)
        # Save to DB
        session = self.session_factory()
        try:
            record = Record(
                source_url=url,
                title=normalized.get("title"),
                description=normalized.get("description"),
                h1_tags=normalized.get("h1_tags"),
                links=normalized.get("links"),
                table_data=normalized.get("table_data"),
                raw_html=normalized.get("raw_html"),
            )
            session.add(record)
            session.commit()
            logger.info("Scheduled scrape stored record %s", record.id)
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    async def shutdown(self) -> None:
        """Cancel all scheduled tasks gracefully."""
        for task in self._tasks:
            task.cancel()
        await asyncio.gather(*self._tasks, return_exceptions=True)
        self._tasks.clear()


# The scheduler will be initialised in app.main where the session factory is available.