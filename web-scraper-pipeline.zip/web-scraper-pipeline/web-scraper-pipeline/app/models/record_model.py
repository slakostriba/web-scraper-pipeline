"""SQLAlchemy model for storing scraped web records.

The ``Record`` model represents a single scraping event. It stores
metadata about the source URL, the time of scraping, extracted
components (title, description, H1 tags, internal links, table
contents), and the raw HTML. JSON fields are used for lists and
tables to simplify storage and retrieval. A UUID primary key ensures
globally unique identifiers.
"""

import datetime
import uuid

from sqlalchemy import Column, String, DateTime, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import declarative_base


Base = declarative_base()


class Record(Base):
    """Database model for a scraped record."""

    __tablename__ = "records"

    id: uuid.UUID = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    source_url: str = Column(String(2048), nullable=False, index=True)
    scraped_at: datetime.datetime = Column(DateTime(timezone=True), default=datetime.datetime.utcnow, nullable=False, index=True)
    title: str | None = Column(String(1024), nullable=True)
    description: str | None = Column(String(2048), nullable=True)
    h1_tags: list[str] | None = Column(JSONB, nullable=True)
    links: list[str] | None = Column(JSONB, nullable=True)
    table_data: list[dict[str, str]] | None = Column(JSONB, nullable=True)
    raw_html: str | None = Column(Text, nullable=True)