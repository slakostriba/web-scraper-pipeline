"""Unit tests for the scraper and normalisation services.

These tests validate that HTML parsing and normalisation behave as
expected and that database inserts work correctly. The Playwright
dependency is mocked out to avoid launching a browser during tests.
"""

from __future__ import annotations

import asyncio
from typing import Any, Dict

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.services.scraper_service import ScraperService
from app.services.normalization_service import NormalizationService
from app.models.record_model import Base, Record


SAMPLE_HTML = """<!DOCTYPE html>
<html>
<head>
  <title>Test Page</title>
  <meta name="description" content="This is a test page for scraping.">
</head>
<body>
  <h1>Main Heading</h1>
  <h1>Second Heading</h1>
  <p>Some content here.</p>
  <table>
    <thead><tr><th>Name</th><th>Age</th></tr></thead>
    <tbody><tr><td>Alice</td><td>30</td></tr><tr><td>Bob</td><td>25</td></tr></tbody>
  </table>
  <a href="/internal/link">Internal Link</a>
</body>
</html>"""


@pytest.mark.asyncio
async def test_extract_static_html(monkeypatch: Any) -> None:
    """Test that the scraper extracts expected elements from static HTML."""
    scraper = ScraperService(timeout=5)

    async def mock_fetch_html(self: ScraperService, url: str) -> str:
        return SAMPLE_HTML

    async def mock_fetch_with_playwright(self: ScraperService, url: str) -> str:
        # Should not be called in this test
        assert False, "Playwright should not be invoked for static HTML"

    def mock_needs_js_rendering(self: ScraperService, soup):
        return False

    # Patch internal methods
    monkeypatch.setattr(ScraperService, "_fetch_html", mock_fetch_html)
    monkeypatch.setattr(ScraperService, "_fetch_with_playwright", mock_fetch_with_playwright)
    monkeypatch.setattr(ScraperService, "_needs_js_rendering", mock_needs_js_rendering)

    data = await scraper.scrape("http://testserver")
    assert data["title"] == "Test Page"
    assert data["description"] == "This is a test page for scraping."
    assert data["h1_tags"] == ["Main Heading", "Second Heading"]
    assert data["links"] == ["http://testserver/internal/link"]
    assert isinstance(data["table_data"], list)
    assert len(data["table_data"]) == 2  # two table rows


def test_normalization() -> None:
    """Test that the normaliser trims whitespace and removes duplicates."""
    normalizer = NormalizationService()
    raw = {
        "title": "  Example Title  ",
        "description": "  Some Description\n",
        "h1_tags": ["Heading", "Heading", " Another "],
        "links": ["/link1 ", "/link1", "/link2"],
        "table_data": [
            {"Name": " Alice ", "Age": " 30 "},
            {"Name": "Bob", "Age": "25"},
        ],
        "raw_html": "<html></html>",
    }
    normalized = normalizer.normalize(raw)
    assert normalized["title"] == "Example Title"
    assert normalized["description"] == "Some Description"
    assert normalized["h1_tags"] == ["Heading", "Another"]
    assert normalized["links"] == ["/link1", "/link2"]
    assert normalized["table_data"] == [
        {"Name": "Alice", "Age": "30"},
        {"Name": "Bob", "Age": "25"},
    ]


def test_db_insert() -> None:
    """Test that a record can be inserted into an in‑memory SQLite database."""
    engine = create_engine("sqlite:///:memory:")
    SessionLocal = sessionmaker(bind=engine)
    Base.metadata.create_all(bind=engine)
    session = SessionLocal()
    try:
        record = Record(
            source_url="http://example.com",
            title="Example",
            description="Desc",
            h1_tags=["Heading"],
            links=["/page"],
            table_data=[{"Name": "Alice", "Age": "30"}],
            raw_html="<html></html>",
        )
        session.add(record)
        session.commit()
        saved = session.query(Record).count()
        assert saved == 1
    finally:
        session.close()